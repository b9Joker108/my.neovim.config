<div align="center">
<a href="#"><img src="./title.png"></a>
</div>

<div align="center">

<img src="https://raw.githubusercontent.com/catppuccin/catppuccin/main/assets/palette/macchiato.png" width="90%"/><br>

</div>

<div align="center">

<a href="https://dotfiles-docs.vercel.app/app-confs/neovim.html#about"><img width="190px" src="https://raw.githubusercontent.com/Matt-FTW/dotfiles/main/.github/assets/category-images/dotfiles-about.png"></a>
<a href="https://dotfiles-docs.vercel.app/app-confs/neovim.html#setup"><img width="190px" src="https://raw.githubusercontent.com/Matt-FTW/dotfiles/main/.github/assets/category-images/dotfiles-setup.png"></a>
<a href="https://dotfiles-docs.vercel.app/app-confs/neovim.html#gallery"><img width="190px" src="https://raw.githubusercontent.com/Matt-FTW/dotfiles/main/.github/assets/category-images/dotfiles-gallery.png"></a>

</div>

<br>

> [!NOTE]
> All the information about the neovim setup is on the documentation website: https://dotfiles-docs.vercel.app/app-confs/neovim.html
