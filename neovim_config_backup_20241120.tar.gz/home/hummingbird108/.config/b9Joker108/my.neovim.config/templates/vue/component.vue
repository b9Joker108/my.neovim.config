<template>
  <div></div>
</template>

<script>
export default {
  name: "${filename}",
  setup() {
    return {};
  },
};
</script>

<style lang="scss" scoped></style>
