return {
  "nyoom-engineering/oxocarbon.nvim",
  lazy = false,
  name = "oxocarbon",
}
