return {
  "olimorris/onedarkpro.nvim",
  lazy = false,
  name = "onedarkpro",
  opts = {},
}
