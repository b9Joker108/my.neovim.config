return {
  "EdenEast/nightfox.nvim",
  lazy = false,
  name = "nightfox",
  opts = {
    options = {},
    groups = {
      all = {
        MatchParen = { fg = "NONE" },
      },
    },
  },
}
