return {
  "NTBBloodbath/doom-one.nvim",
  lazy = false,
  name = "doom-one",
}
