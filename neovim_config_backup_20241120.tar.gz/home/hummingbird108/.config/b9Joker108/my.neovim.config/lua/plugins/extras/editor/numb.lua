return {
  "nacro90/numb.nvim",
  event = "CmdlineEnter",
  opts = {},
}
