return {
  "shortcuts/no-neck-pain.nvim",
  opts = {},
  -- stylua: ignore
  keys = {
    { "<leader>uN", "<cmd>NoNeckPain<cr>", desc = "No Neck Pain" },
  },
}
