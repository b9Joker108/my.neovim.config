return {
  "nyngwang/nvimgelion",
  name = "nvimgelion",
  lazy = false,
  opts = {},
}
