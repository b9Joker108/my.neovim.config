return {
  "kevinhwang91/nvim-ibus-sw",
  event = "InsertLeave",
  opts = {},
}
