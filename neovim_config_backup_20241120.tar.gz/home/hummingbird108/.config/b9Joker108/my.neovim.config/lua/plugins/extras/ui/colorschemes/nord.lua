return {
  "shaunsingh/nord.nvim",
  lazy = false,
  name = "nord",
}
