return {
  "ejrichards/mise.nvim",
  event = "VeryLazy",
  opts = {},
}
