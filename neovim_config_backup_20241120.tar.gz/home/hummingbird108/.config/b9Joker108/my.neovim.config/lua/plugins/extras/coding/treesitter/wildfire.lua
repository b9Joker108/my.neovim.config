return {
  "sustech-data/wildfire.nvim",
  event = "BufEnter",
  vscode = true,
  opts = {},
}
