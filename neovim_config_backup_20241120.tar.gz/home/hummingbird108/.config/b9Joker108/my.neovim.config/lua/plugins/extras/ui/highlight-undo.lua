return {
  "tzachar/highlight-undo.nvim",
  event = "LazyFile",
  vscode = true,
  opts = {
    duration = 700,
  },
}
