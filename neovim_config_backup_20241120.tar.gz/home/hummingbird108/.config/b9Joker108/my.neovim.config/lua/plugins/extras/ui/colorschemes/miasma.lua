return {
  "xero/miasma.nvim",
  name = "miasma",
  lazy = false,
}
