return {
  "mhartington/oceanic-next",
  name = "oceanic-next",
  lazy = false,
}
