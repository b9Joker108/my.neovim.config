return {
  "rmehri01/onenord.nvim",
  name = "onenord",
  lazy = false,
  opts = {},
}
