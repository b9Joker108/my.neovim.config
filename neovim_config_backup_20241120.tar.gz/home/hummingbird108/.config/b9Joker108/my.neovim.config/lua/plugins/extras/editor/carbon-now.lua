return {
  "kristijanhusak/vim-carbon-now-sh",
  cmd = "CarbonNowSh",
  vscode = true,
}
