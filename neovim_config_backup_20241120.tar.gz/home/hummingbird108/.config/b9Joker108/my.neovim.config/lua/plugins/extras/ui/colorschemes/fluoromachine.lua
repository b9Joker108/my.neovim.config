return {
  "maxmx03/fluoromachine.nvim",
  lazy = false,
  name = "fluoromachine",
  opts = {},
}
