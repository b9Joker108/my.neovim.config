return {
  "zbirenbaum/neodim",
  event = "LspAttach",
  opts = {
    alpha = 0.60,
  },
}
