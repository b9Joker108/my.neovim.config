return {
  "HoNamDuong/hybrid.nvim",
  name = "hybrid",
  lazy = false,
  opts = {},
}
