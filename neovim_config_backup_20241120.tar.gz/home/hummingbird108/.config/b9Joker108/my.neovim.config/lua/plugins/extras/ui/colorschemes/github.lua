return {
  "projekt0n/github-nvim-theme",
  lazy = false,
  name = "github",
}
