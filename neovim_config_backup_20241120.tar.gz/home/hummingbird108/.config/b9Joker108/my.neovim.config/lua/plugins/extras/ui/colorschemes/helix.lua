return {
  "oneslash/helix-nvim",
  lazy = false,
  name = "helix",
  opts = {},
}
