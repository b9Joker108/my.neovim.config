return {
  "rockerBOO/boo-colorscheme-nvim",
  name = "boo",
  lazy = false,
}
