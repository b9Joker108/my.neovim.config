return {
  "xiyaowong/nvim-transparent",
  opts = {},
  keys = {
    { "<leader>uP", "<Cmd>TransparentToggle<CR>", desc = "Toggle Transparent" },
  },
}
