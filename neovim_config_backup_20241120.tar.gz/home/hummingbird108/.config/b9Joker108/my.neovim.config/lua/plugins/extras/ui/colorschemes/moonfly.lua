return {
  "bluz71/vim-moonfly-colors",
  name = "moonfly",
  lazy = false,
}
