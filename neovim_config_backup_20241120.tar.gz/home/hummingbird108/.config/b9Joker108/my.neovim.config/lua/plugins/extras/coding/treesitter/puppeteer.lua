return {
  "nvim-treesitter/nvim-treesitter",
  dependencies = { "chrisgrieser/nvim-puppeteer" },
}
