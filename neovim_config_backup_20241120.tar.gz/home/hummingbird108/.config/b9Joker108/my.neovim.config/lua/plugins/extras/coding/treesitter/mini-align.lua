return {
  "echasnovski/mini.align",
  opts = {},
  vscode = true,
  keys = {
    { "ga", mode = { "n", "v" }, desc = "Align" },
    { "gA", mode = { "n", "v" }, desc = "Align Preview" },
  },
}
