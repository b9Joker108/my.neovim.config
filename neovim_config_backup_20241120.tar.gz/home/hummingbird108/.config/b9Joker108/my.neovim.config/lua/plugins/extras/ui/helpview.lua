return {
  "OXY2DEV/helpview.nvim",
  ft = "help",
  opts = {},
}
