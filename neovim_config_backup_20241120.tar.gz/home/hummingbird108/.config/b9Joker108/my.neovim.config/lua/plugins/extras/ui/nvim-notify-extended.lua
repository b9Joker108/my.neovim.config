return {
  "rcarriga/nvim-notify",
  opts = {
    fps = 75,
    stages = "slide",
    render = "wrapped-compact",
    timeout = 2000,
  },
}
