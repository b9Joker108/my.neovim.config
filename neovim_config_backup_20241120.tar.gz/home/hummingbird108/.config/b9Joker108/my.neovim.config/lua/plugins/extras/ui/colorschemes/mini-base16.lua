return {
  "echasnovski/mini.base16",
  lazy = false,
  name = "base16",
}
