return {
  "mvllow/modes.nvim",
  event = "VeryLazy",
  opts = {},
}
