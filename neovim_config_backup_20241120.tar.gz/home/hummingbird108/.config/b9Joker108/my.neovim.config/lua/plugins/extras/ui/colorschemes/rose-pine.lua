return {
  "rose-pine/neovim",
  lazy = false,
  name = "rose-pine",
  opts = {
    highlight_groups = {
      EndOfBuffer = { fg = "base" },
    },
  },
}
