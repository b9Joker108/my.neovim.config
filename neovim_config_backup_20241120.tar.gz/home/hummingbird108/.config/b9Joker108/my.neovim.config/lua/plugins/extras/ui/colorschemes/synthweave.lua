return {
  "samharju/synthweave.nvim",
  name = "synthweave",
  lazy = false,
  opts = {},
}
