return {
  "rebelot/kanagawa.nvim",
  lazy = false,
  name = "kanagawa",
  opts = {},
}
