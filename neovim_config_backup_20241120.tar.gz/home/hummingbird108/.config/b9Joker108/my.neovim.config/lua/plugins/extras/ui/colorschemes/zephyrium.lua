return {
  "titanzero/zephyrium",
  name = "zephyrium",
  lazy = false,
}
