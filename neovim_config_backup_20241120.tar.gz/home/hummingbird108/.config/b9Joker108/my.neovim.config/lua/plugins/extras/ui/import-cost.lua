return {
  "barrett-ruth/import-cost.nvim",
  build = "sh install.sh npm",
  event = "LazyFile",
  config = true,
}
