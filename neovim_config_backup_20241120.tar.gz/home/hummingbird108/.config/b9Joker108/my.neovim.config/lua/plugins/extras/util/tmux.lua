return {
  "aserowy/tmux.nvim",
  event = "VeryLazy",
  opts = {},
}
