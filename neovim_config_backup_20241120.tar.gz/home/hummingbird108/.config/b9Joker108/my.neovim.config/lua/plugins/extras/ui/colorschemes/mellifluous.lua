return {
  "ramojus/mellifluous.nvim",
  name = "mellifluous",
  lazy = false,
  opts = {},
}
