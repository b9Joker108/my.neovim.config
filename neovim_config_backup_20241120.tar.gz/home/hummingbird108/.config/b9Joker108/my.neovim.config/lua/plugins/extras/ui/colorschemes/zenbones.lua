return {
  "mcchrish/zenbones.nvim",
  name = "zenbones",
  lazy = false,
  opts = {},
}
