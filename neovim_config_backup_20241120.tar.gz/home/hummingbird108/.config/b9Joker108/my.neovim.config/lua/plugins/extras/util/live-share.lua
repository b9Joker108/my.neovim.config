return {
  "azratul/live-share.nvim",
  cmd = { "LiveShareServer", "LiveShareJoin" },
  dependencies = {
    "jbyuki/instant.nvim",
  },
  opts = {},
}
