return {
  "lewpoly/sherbet.nvim",
  name = "sherbet",
  lazy = false,
}
