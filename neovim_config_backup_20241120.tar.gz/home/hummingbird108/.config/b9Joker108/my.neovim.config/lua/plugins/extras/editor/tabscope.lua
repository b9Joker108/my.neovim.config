return {
  "akinsho/bufferline.nvim",
  optional = true,
  dependencies = {
    "backdround/tabscope.nvim",
    opts = {},
  },
}
