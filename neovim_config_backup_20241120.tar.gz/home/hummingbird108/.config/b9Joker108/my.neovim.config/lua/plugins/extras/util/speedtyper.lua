return {
  "NStefan002/speedtyper.nvim",
  cmd = "Speedtyper",
  opts = {},
}
