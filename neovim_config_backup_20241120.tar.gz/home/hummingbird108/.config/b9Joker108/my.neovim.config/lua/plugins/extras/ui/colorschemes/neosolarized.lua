return {
  "Tsuzat/NeoSolarized.nvim",
  lazy = false,
  name = "solarized",
}
