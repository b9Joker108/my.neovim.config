return {
  "ThePrimeagen/vim-be-good",
  cmd = "VimBeGood",
}
