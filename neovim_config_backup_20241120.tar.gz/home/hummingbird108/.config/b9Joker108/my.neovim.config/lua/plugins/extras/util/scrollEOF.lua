return {
  "Aasim-A/scrollEOF.nvim",
  event = "CursorMoved",
  opts = {},
}
