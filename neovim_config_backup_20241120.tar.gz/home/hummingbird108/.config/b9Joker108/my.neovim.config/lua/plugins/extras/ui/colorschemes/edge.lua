return {
  "sainnhe/edge",
  name = "edge",
  lazy = false,
}
