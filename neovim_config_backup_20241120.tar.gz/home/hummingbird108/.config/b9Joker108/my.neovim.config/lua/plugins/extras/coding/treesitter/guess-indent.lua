return {
  "nmac427/guess-indent.nvim",
  event = "LazyFile",
  opts = {},
}
