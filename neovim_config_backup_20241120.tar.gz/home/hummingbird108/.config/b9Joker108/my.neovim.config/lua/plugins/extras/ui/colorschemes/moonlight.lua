return {
  "shaunsingh/moonlight.nvim",
  name = "moonlight",
  lazy = false,
}
