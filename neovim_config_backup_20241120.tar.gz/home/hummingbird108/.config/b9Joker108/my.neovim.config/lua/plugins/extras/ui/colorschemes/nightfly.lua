return {
  "bluz71/vim-nightfly-colors",
  name = "nightfly",
  lazy = false,
}
