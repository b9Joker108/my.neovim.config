return {
  "Everblush/nvim",
  name = "everblush",
  lazy = false,
  opts = {},
}
