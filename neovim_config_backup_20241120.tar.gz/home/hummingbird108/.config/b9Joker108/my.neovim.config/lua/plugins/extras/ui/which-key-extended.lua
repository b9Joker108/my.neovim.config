return {
  "folke/which-key.nvim",
  opts = {
    icons = {
      group = "",
    },
    spec = {
      { "<leader>ci", group = "info", icon = " " },
      { "<leader>l", group = "lazy", icon = "󰒲 " },
    },
  },
}
