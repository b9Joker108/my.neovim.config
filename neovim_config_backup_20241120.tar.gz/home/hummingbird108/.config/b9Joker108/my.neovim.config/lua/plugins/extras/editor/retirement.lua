return {
  "chrisgrieser/nvim-early-retirement",
  event = "VeryLazy",
  opts = {
    retirementAgeMins = 30,
    ignoreUnsavedChangesBufs = false,
  },
}
