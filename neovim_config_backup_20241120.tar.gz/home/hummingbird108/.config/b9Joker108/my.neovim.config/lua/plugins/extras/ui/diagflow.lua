return {
  "dgagn/diagflow.nvim",
  event = "LspAttach",
  opts = {},
}
