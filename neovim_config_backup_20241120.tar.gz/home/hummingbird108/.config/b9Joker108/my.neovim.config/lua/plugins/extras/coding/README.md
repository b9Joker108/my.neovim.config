#  Neovim Plugins Extras README.md

I have added: 'nomnivore/ollama.nvim' on Thursday, November 14, 2024
