return {
  "creativenull/dotfyle-metadata.nvim",
  cmd = { "DotfyleGenerate", "DotfyleOpen" },
}
