return {
  "sainnhe/everforest",
  lazy = false,
  name = "everforest",
  opts = {},
}
