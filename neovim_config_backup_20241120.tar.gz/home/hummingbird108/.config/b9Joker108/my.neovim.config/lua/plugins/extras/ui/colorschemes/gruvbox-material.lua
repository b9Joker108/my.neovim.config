return {
  "sainnhe/gruvbox-material",
  name = "gruvbox-material",
  lazy = false,
}
