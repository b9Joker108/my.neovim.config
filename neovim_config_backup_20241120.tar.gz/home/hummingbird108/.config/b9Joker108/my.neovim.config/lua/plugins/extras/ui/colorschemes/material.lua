return {
  "marko-cerovac/material.nvim",
  lazy = false,
  name = "material",
  opts = {},
}
