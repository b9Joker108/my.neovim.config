return {
  "kaiuri/nvim-juliana",
  lazy = false,
  name = "juliana",
}
