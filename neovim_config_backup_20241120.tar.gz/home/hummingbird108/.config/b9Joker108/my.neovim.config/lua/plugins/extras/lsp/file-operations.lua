return {
  "nvim-neo-tree/neo-tree.nvim",
  optional = true,
  dependencies = {
    "antosha417/nvim-lsp-file-operations",
    opts = {},
  },
}
