return {
  "smjonas/inc-rename.nvim",
  cmd = "IncRename",
  opts = {},
}
