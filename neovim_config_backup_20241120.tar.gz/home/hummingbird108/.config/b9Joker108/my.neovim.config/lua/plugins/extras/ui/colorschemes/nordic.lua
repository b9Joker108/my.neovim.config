return {
  "AlexvZyl/nordic.nvim",
  lazy = false,
  name = "nordic",
  opts = {},
}
