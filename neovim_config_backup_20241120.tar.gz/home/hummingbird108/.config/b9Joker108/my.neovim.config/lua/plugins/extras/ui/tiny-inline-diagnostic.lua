return {
  "rachartier/tiny-inline-diagnostic.nvim",
  event = "VeryLazy",
  opts = {},
}
