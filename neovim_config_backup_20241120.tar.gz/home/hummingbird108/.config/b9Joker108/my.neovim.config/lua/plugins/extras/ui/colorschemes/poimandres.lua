return {
  "olivercederborg/poimandres.nvim",
  lazy = false,
  name = "poimandres",
  opts = {},
}
