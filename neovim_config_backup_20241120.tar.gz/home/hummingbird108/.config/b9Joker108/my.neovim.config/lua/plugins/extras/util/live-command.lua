return {
  "smjonas/live-command.nvim",
  event = "VeryLazy",
  opts = {},
}
