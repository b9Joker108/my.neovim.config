return {
  "rasulomaroff/reactive.nvim",
  event = "VeryLazy",
  opts = {},
  keys = {
    { "<leader>uM", "<cmd>ReactiveToggle<cr>", desc = "Mode Lines" },
  },
}
