return {
  "sainnhe/sonokai",
  lazy = false,
  name = "sonokai",
  opts = {},
}
