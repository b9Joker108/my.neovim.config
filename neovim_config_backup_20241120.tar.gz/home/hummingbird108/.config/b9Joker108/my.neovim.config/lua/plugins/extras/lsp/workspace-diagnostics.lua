return {
  "artemave/workspace-diagnostics.nvim",
  event = "LspAttach",
  opts = {},
}
