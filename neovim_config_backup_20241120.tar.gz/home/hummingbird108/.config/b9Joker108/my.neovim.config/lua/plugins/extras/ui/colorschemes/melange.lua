return {
  "savq/melange-nvim",
  lazy = false,
  name = "melange",
}
