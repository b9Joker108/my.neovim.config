return {
  "max397574/better-escape.nvim",
  opts = {},
  event = "InsertEnter",
}
