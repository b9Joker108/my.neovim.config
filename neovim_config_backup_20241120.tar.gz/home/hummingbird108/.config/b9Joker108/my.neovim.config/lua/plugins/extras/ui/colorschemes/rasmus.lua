return {
  "kvrohit/rasmus.nvim",
  name = "rasmus",
  lazy = false,
}
