return {
  "Mofiqul/dracula.nvim",
  lazy = false,
  name = "dracula",
  opts = {},
}
