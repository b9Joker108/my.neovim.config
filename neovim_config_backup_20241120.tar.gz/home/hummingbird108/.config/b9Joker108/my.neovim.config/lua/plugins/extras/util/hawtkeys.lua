return {
  "tris203/hawtkeys.nvim",
  cmd = { "Hawtkeys", "HawtkeysDupes", "HawtkeysAll" },
  opts = {},
}
