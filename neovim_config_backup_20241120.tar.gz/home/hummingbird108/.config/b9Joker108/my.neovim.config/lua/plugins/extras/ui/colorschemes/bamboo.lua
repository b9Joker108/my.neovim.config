return {
  "ribru17/bamboo.nvim",
  name = "bamboo",
  lazy = false,
}
