return {
  "HakonHarnes/img-clip.nvim",
  opts = {},
  keys = {
    { "<leader>P", "<cmd>PasteImage<cr>", desc = "Paste Clipboard Image" },
  },
}
