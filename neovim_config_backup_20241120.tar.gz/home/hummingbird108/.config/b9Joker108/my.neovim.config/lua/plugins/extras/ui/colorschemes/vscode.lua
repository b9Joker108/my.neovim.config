return {
  "Mofiqul/vscode.nvim",
  lazy = false,
  name = "vscode",
  opts = {},
}
