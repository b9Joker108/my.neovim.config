return {
  "miikanissi/modus-themes.nvim",
  name = "modus",
  lazy = false,
  opts = {},
}
